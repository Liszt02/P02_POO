﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class Caminhao : Veiculo
    {
        private int eixos;

        public Caminhao(string plate, int year, int eixos) : base(plate,year)
        {
            this.eixos= eixos;
        }
        public int Eixos { get => eixos; set => eixos = value; }

        public override double Alugar()
        {
            return (300 * eixos) - (2024 - Year) * 50;
        }
    }
}
