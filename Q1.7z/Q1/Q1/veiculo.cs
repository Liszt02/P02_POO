﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal abstract class Veiculo
    {
        private string plate;
        private int year;
        public Veiculo()
        {
            plate= string.Empty;
            year=0;
        }

        public Veiculo(string plate, int year)
        {
            this.plate = plate;
            this.year = year;
        }
        public string Plate { get => plate; set => plate = value; }
        public int Year { get => year; set => year = value; }

        public abstract double Alugar();

    }
}
