﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class Onibus : Veiculo
    {
        private int seats;

        public Onibus(string plate, int year, int seats) : base(plate,year)
        { 
            this.seats = seats;
        }
        public int Seats { get => seats; set => seats = value; }

        public override double Alugar()
        {
            return (30 * seats) - (2024 - Year) * 70;
        }
    }
}
