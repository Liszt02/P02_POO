﻿namespace Q1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ano = new System.Windows.Forms.TextBox();
            this.qtd_assentos = new System.Windows.Forms.TextBox();
            this.bus = new System.Windows.Forms.RadioButton();
            this.truck = new System.Windows.Forms.RadioButton();
            this.cad = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Imagens = new System.Windows.Forms.PictureBox();
            this.placa = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Imagens)).BeginInit();
            this.SuspendLayout();
            // 
            // ano
            // 
            this.ano.Location = new System.Drawing.Point(114, 109);
            this.ano.Name = "ano";
            this.ano.Size = new System.Drawing.Size(153, 20);
            this.ano.TabIndex = 1;
            this.ano.TextChanged += new System.EventHandler(this.ano_TextChanged);
            // 
            // qtd_assentos
            // 
            this.qtd_assentos.Location = new System.Drawing.Point(114, 149);
            this.qtd_assentos.Name = "qtd_assentos";
            this.qtd_assentos.Size = new System.Drawing.Size(153, 20);
            this.qtd_assentos.TabIndex = 2;
            // 
            // bus
            // 
            this.bus.AutoSize = true;
            this.bus.Location = new System.Drawing.Point(114, 40);
            this.bus.Name = "bus";
            this.bus.Size = new System.Drawing.Size(58, 17);
            this.bus.TabIndex = 3;
            this.bus.TabStop = true;
            this.bus.Text = "Ônibus";
            this.bus.UseVisualStyleBackColor = true;
            this.bus.CheckedChanged += new System.EventHandler(this.bus_CheckedChanged);
            // 
            // truck
            // 
            this.truck.AutoSize = true;
            this.truck.Location = new System.Drawing.Point(189, 40);
            this.truck.Name = "truck";
            this.truck.Size = new System.Drawing.Size(72, 17);
            this.truck.TabIndex = 4;
            this.truck.TabStop = true;
            this.truck.Text = "Caminhão";
            this.truck.UseVisualStyleBackColor = true;
            this.truck.CheckedChanged += new System.EventHandler(this.truck_CheckedChanged);
            // 
            // cad
            // 
            this.cad.Location = new System.Drawing.Point(86, 194);
            this.cad.Name = "cad";
            this.cad.Size = new System.Drawing.Size(86, 32);
            this.cad.TabIndex = 5;
            this.cad.Text = "Cadastrar";
            this.cad.UseVisualStyleBackColor = true;
            this.cad.Click += new System.EventHandler(this.cad_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(193, 194);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(86, 32);
            this.clear.TabIndex = 6;
            this.clear.Text = "Limpar";
            this.clear.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(25, 257);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(532, 176);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Imagens
            // 
            this.Imagens.Image = global::Q1.Properties.Resources.branco;
            this.Imagens.Location = new System.Drawing.Point(307, 21);
            this.Imagens.Name = "Imagens";
            this.Imagens.Size = new System.Drawing.Size(250, 205);
            this.Imagens.TabIndex = 9;
            this.Imagens.TabStop = false;
            this.Imagens.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // placa
            // 
            this.placa.Location = new System.Drawing.Point(114, 75);
            this.placa.Mask = "____-___";
            this.placa.Name = "placa";
            this.placa.Size = new System.Drawing.Size(152, 20);
            this.placa.TabIndex = 10;
            this.placa.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.placa_MaskInputRejected_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 623);
            this.Controls.Add(this.placa);
            this.Controls.Add(this.Imagens);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.cad);
            this.Controls.Add(this.truck);
            this.Controls.Add(this.bus);
            this.Controls.Add(this.qtd_assentos);
            this.Controls.Add(this.ano);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Imagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox ano;
        private System.Windows.Forms.TextBox qtd_assentos;
        private System.Windows.Forms.RadioButton bus;
        private System.Windows.Forms.RadioButton truck;
        private System.Windows.Forms.Button cad;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox Imagens;
        private System.Windows.Forms.MaskedTextBox placa;
    }
}

