﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class Pilha
    {
        Nopilha topo;

        public Pilha()
        {
            topo = null;
        }

        internal Nopilha Topo { get => topo; set => topo = value; }

        public bool Empty()
        {
            if (topo == null)
            {
                return true;
            }
            else return false;
        }

        public void Push(Nopilha noparte)
        {
            noparte.Next = topo;
            topo = noparte;
        }
        public Nopilha Pop()
        {
            Nopilha temp = topo;
            if (topo==null)
            {
                Console.WriteLine("A pilha está vazia!");
                return temp;
            }
            topo = topo.Next;
            return temp;

        }

        public void Troca(string vp,string novaparte)
        {
            Pilha temp = new();
            Nopilha np = new ();
            np.Info.nome = vp;
            while (!Empty())
            {
                if (topo.Info.nome == vp)
                {
                    Pop();
                    Push(np);
                    while (!temp.Empty())
                    {
                        Push(temp.Pop());
                    }
                    return;
                }
                else
                {
                    temp.Push(Pop());
                }
            }
            return;
        }
    }
}
