﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class Nopilha
    {
        Parte info;
        Nopilha next;

        public Nopilha()
        {
            info = new Parte();
            next = null;
        }
        public Nopilha(Parte info)
        {
            this.info = info;
            this.next = null;
        }

        internal Parte Info { get => info; set => info = value; }
        internal Nopilha Next { get => next; set => next = value; }
    }
}
